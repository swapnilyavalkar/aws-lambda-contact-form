const AWS = require('aws-sdk');
const sns = new AWS.SNS();

exports.handler = async (event) => {
    const { name, email, message } = JSON.parse(event.body);

    const snsParams = {
        Message: `New contact form submission:\nName: ${name}\nEmail: ${email}\nMessage: ${message}`,
        Subject: 'Contact Form Submission',
        TopicArn: 'arn:aws:sns:ap-south-1:307946656533:MyTopic'  // Replace with actual SNS Topic ARN
    };

    try {
        await sns.publish(snsParams).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Form submitted successfully!' })
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Failed to submit form.', error })
        };
    }
};